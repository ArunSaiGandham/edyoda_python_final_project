# This modile is for password encrypt and dycript 

class password_hasing():
    def __inti__(self):
        pass
    def encrypt(self,password):
        pass_list = list(password)
        pass_len = len(pass_list)
        for chr in pass_list:
            index_pos = (ord(chr) * pass_len)/pass_len
            print(index_pos)
        print(pass_list)


obj = password_hasing()
obj.encrypt("ABC")